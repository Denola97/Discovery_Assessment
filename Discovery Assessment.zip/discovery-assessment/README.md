## Assessment

Use the files contained within this directory to configure a basic Bootstrap / Gulp project. 
The idea is to make use of this 'boilerplate' project to create a Bootstrap themed web-page.

To kick start the project by running

```
npm install
```

#### Brief - to test the candidate's understanding of Gulp, Bootstrap and SCSS. 
Create the two Discovery themed web pages on the Figma file provided: https://www.figma.com/file/wZiq7HfxRJN0mnW64dgJKF/Front-end-Assessment?node-id=0%3A1 (Page 1 & Page 2), by making use of the files contained within this directory. 

#### You can use an HTML templating library.









