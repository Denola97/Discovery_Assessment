function hasInParents(el, id) {
  if (el.id === id) return true;
  if (el.parentNode) return hasInParents(el.parentNode, id);
  return false;
}

function hasInParentsUntil(el, id, limit) {
  if (el.id === id) return true;
  if (el.parentNode) return hasInParents(el.parentNode, id);
  return false;
}

var selectedMeganavId = '',
  topLevelItems = document.querySelectorAll('[data-dui-nav-target]'),
  navigationContainer = document.getElementById('js-navigation-container'),
  closeNav = document.getElementById('js-close-nav'),
  mobileNavTrigger = document.getElementById('js-mobile-nav-trigger'),
  navigationContainerInner = document.getElementById('js-navigation-inner-container'),
  targetId = '';


var toggleMegaNav = function (e, el) {
  e.preventDefault();

  var target = e.target || e.srcElement;

  if (hasInParentsUntil(e.target, 'js-mobile-nav-trigger', el)) {

    el = mobileNavTrigger;
    targetId = 'js-mobile-nav-trigger'
  } else {
    targetId = target.id || target.parentNode.id;
  }

  var meganavId = el.getAttribute("data-dui-nav-target"),
    meganavContent = document.querySelectorAll('[data-dui-nav-container-id="' + meganavId + '"]');


  if (hasClass(mobileNavTrigger, "is-active")) {

    if (targetId === 'js-mobile-nav-trigger') {
      if (hasClass(mobileNavTrigger, "is-active")) {
        mobileNavTrigger.classList.remove('is-active');
      } else {
        mobileNavTrigger.classList.add('is-active');
      }
    }

    _closeMeganav(navigationContainer, navigationContainerInner);

  } else {

    if (targetId === 'js-mobile-nav-trigger') {
      if (hasClass(mobileNavTrigger, "is-active")) {
        mobileNavTrigger.classList.remove('is-active');
      } else {
        mobileNavTrigger.classList.add('is-active');
      }
    }

    navigationContainerInner.innerHTML = '';
    navigationContainerInner.innerHTML = meganavContent[0].innerHTML;

    if (navigationContainer.hasAttribute("data-showing") && (meganavId === selectedMeganavId)) {
      selectedMeganavId = meganavId;

      _closeMeganav(navigationContainer, navigationContainerInner);
      selectedMeganavId = '';
      navigationContainer.removeAttribute("data-showing");

    } else {

      selectedMeganavId = '';
      if (!navigationContainer.hasAttribute("data-showing")) {
        _openMeganav(navigationContainer);
        navigationContainer.setAttribute("data-showing", "true");
      }
    }
  }

  if (targetId === 'js-login-btn') {
    var usernameField = document.getElementById('username');
    if (usernameField) {
      usernameField.focus();
    }
  }

  if (targetId === 'js-search-trigger') {
    var mainSearchField = document.getElementById('mainSearchQuery');
    if (mainSearchField) {
      mainSearchField.focus();
    }
  }

  if (meganavId !== selectedMeganavId) {
    selectedMeganavId = meganavId;
  }


};

for (var i = 0; i < topLevelItems.length; i++) {
  topLevelItems[i].addEventListener('click', function (e) {
    toggleMegaNav(e, this);
  });
}

closeNav.addEventListener('click', function () {
  _closeMeganav(navigationContainer, navigationContainerInner, selectedMeganavId);
}, false);

document.addEventListener("click", function (e) {
  var level = 0;
  for (var element = e.target; element; element = element.parentNode) {
    if (element.id === 'js-site-header'
      || element.id === 'js-login-btn'
      || element.id === 'js-search-trigger'
      || element.id === 'js-mobile-nav-trigger') {
      return;
    }
    level++;
  }

  _closeMeganav(navigationContainer, navigationContainerInner);

  mobileNavTrigger.classList.remove('is-active');

  selectedMeganavId = '';
});

function hasClass(el, cls) {
  return el.className && new RegExp("(\\s|^)" + cls + "(\\s|$)").test(el.className);
}

function isHidden(el) {
  return (el.offsetParent === null)
}

function _closeMeganav(navigationContainer, navigationContainerInner) {
  if ((typeof $ != 'undefined') && (typeof $.Velocity != 'undefined')) {
    $.Velocity.animate(navigationContainer, 'slideUp', {
      duration: 300,
      easing: 'easeIn',
      complete: function () {
        navigationContainerInner.innerHTML = '';
      }
    });
  } else {
    navigationContainer.style.display = "none";
  }

  navigationContainer.removeAttribute("data-showing");
}

function _openMeganav(navigationContainer) {
  if ((typeof $ != 'undefined') && (typeof $.Velocity != 'undefined')) {

    $.Velocity.animate(navigationContainer, 'slideDown', {
      duration: 300,
      easing: 'easeIn',
      complete: function () {
        if (targetId === 'js-login-btn') {
          var usernameField = document.getElementById('username');
          if (usernameField) {
            usernameField.focus();
          }
        }

        if (targetId === 'js-search-trigger') {
          var mainSearchQueryField = document.getElementById('mainSearchQuery');
          if (mainSearchQueryField) {
            mainSearchQueryField.focus();
          }
        }
      }
    });
  } else {
    navigationContainer.style.display = "block";

    if (targetId === 'js-login-btn') {
      var usernameField = document.getElementById('username');
      if (usernameField) {
        usernameField.focus();
      }
    }

    if (targetId === 'js-search-trigger') {
      var mainSearchQueryField = document.getElementById('mainSearchQuery');
      if (mainSearchQueryField) {
        mainSearchQueryField.focus();
      }
    }
  }

  navigationContainer.setAttribute("data-showing", "true");
}